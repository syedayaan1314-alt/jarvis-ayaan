const $ = (s) => document.querySelector(s);
const messages = $("#messages");
const input = $("#messageInput");
const form = $("#chatForm");
const chatHistory = [];
let listening = false;
let recognition = null;

function updateClock() {
  const now = new Date();
  $("#clock").textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  $("#dateText").textContent = now.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" }).toUpperCase();
}
updateClock();
setInterval(updateClock, 30000);

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = navigator.language || "en-US";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  $("#voiceStatus").textContent = "Supported in this browser";
  $("#voiceTag").textContent = "READY";
  recognition.onresult = (event) => {
    const transcript = event.results?.[0]?.[0]?.transcript || "";
    input.value = transcript;
    input.focus();
    if (transcript) form.requestSubmit();
  };
  recognition.onerror = () => setListening(false);
  recognition.onend = () => setListening(false);
} else {
  $("#voiceStatus").textContent = "Try Chrome or Edge on a supported device";
  $("#voiceTag").textContent = "LIMITED";
  $("#voiceTag").classList.add("idle");
}

function setListening(value) {
  listening = value;
  $("#micButton").classList.toggle("listening", value);
  $("#micButton").textContent = value ? "■" : "♩";
  $("#connectionStatus").textContent = value ? "VOICE INPUT ACTIVE" : "LOCAL INTERFACE READY";
}

function addMessage(role, text) {
  const wrap = document.createElement("div");
  wrap.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "assistant" ? "J" : "S";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (role === "assistant") {
    const label = document.createElement("span");
    label.className = "message-label";
    label.textContent = "JARVIS";
    bubble.appendChild(label);
  }
  const content = document.createElement("span");
  content.textContent = text;
  bubble.appendChild(content);
  if (role === "user") wrap.appendChild(bubble);
  else { wrap.appendChild(avatar); wrap.appendChild(bubble); }
  messages.appendChild(wrap);
  messages.scrollTop = messages.scrollHeight;
  return wrap;
}

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1;
  utterance.pitch = 0.95;
  window.speechSynthesis.speak(utterance);
}

async function sendMessage(text) {
  const message = text.trim();
  if (!message) return;
  addMessage("user", message);
  input.value = "";
  const pending = addMessage("assistant", "One moment, Sir...");
  const content = pending.querySelector(".bubble span:last-child");
  const sendButton = $(".send-button");
  sendButton.disabled = true;
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, history: chatHistory })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "The request failed.");
    const reply = data.reply || "I don't have a reply yet.";
    content.textContent = reply;
    chatHistory.push({ role: "user", text: message }, { role: "model", text: reply });
    if (chatHistory.length > 12) chatHistory.splice(0, chatHistory.length - 12);
    speak(reply);
  } catch (error) {
    content.textContent = error.message || "Couldn't connect. Check your network and server setup.";
  } finally {
    sendButton.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage(input.value);
});
$("#micButton").addEventListener("click", () => {
  if (!recognition) {
    addMessage("assistant", "Voice input isn't supported in this browser. Try Chrome or Edge, and allow microphone access when prompted.");
    return;
  }
  if (listening) { recognition.stop(); setListening(false); return; }
  try { recognition.start(); setListening(true); }
  catch { setListening(false); addMessage("assistant", "The microphone is busy. Please try again in a moment."); }
});
$("#voiceAction").addEventListener("click", () => $("#micButton").click());
$("#youtubeAction").addEventListener("click", () => window.open("https://www.youtube.com/", "_blank", "noopener,noreferrer"));
$("#gmailAction").addEventListener("click", () => window.open("https://mail.google.com/", "_blank", "noopener,noreferrer"));
$("#clearChat").addEventListener("click", () => {
  chatHistory.length = 0;
  messages.replaceChildren();
  addMessage("assistant", "Chat cleared, Sir. How can I help?");
});
$("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));

const homeView = $("#homeView");
const chatPanel = $("#chatPanel");
const detailView = $("#detailView");
const detailContent = $("#detailContent");
const views = {
  systems: {
    title: "System Control",
    html: `<p>JARVIS can display browser information, but a website cannot silently control your whole PC or Android phone.</p>
      <div class="setting-note"><strong>Available in this starter:</strong> responsive dashboard, text chat, microphone input (browser-dependent), spoken replies, and links that open Gmail or YouTube.</div>
      <p>For operating-system actions, add a separately installed Windows companion app with narrowly scoped permissions. Android requires its own permission-aware app or supported OS integration.</p>`
  },
  integrations: {
    title: "Integrations",
    html: `<p>These are setup guides, not active account connections. No account has been connected by this project.</p>
      <div class="integration-list">
      <div class="integration-card"><h3>✉ Gmail</h3><p>Opens Gmail. API access requires a Google Cloud project, Gmail API, OAuth consent, and server-side token handling.</p><button data-open="https://mail.google.com/">Open Gmail ↗</button></div>
      <div class="integration-card"><h3>▷ YouTube</h3><p>Opens YouTube. Search and playback integrations can be added with supported APIs and permissions.</p><button data-open="https://www.youtube.com/">Open YouTube ↗</button></div>
      <div class="integration-card"><h3>⌘ Chrome</h3><p>This website can open links. Browser tab control needs a separate Chrome extension and explicit extension permissions; mobile Chrome has different limits.</p><button data-open="https://developer.chrome.com/docs/extensions/">Extension docs ↗</button></div>
      <div class="integration-card"><h3>◌ WhatsApp</h3><p>WhatsApp messaging requires a supported official integration and account setup. This starter does not read chats or send messages.</p><button data-open="https://developers.facebook.com/docs/whatsapp/cloud-api/">Official API docs ↗</button></div>
      </div>
      <div class="setting-note">For privacy, never paste passwords, OAuth tokens, or API keys into the chat. Connect accounts only through their official consent screens.</div>`
  },
  settings: {
    title: "Settings & secure setup",
    html: `<p>Configure your server key outside the browser. The frontend never receives the Gemini API key.</p>
      <ol><li>Copy <code>.env.example</code> to <code>.env.local</code>.</li><li>Set <code>GEMINI_API_KEY</code> in the local environment.</li><li>Run <code>npm install</code>, then <code>npm run dev</code>.</li><li>For Vercel, add <code>GEMINI_API_KEY</code> under Project Settings → Environment Variables, then redeploy.</li></ol>
      <div class="setting-note">Do not commit .env.local to GitHub. Use Vercel's environment-variable settings for deployments. API usage may incur costs or quota limits.</div>`
  }
};
function setView(view) {
  document.querySelectorAll(".nav-item").forEach(btn => btn.classList.toggle("active", btn.dataset.view === view));
  $("#sidebar").classList.remove("open");
  if (view === "home" || view === "chat") {
    detailView.classList.add("hidden");
    homeView.classList.remove("hidden");
    chatPanel.classList.remove("hidden");
    if (view === "chat") { chatPanel.scrollIntoView({ behavior: "smooth", block: "start" }); input.focus(); }
    return;
  }
  const item = views[view];
  if (!item) return;
  homeView.classList.add("hidden");
  chatPanel.classList.add("hidden");
  detailView.classList.remove("hidden");
  detailContent.innerHTML = `<span class="eyebrow">JARVIS CONTROL CENTRE</span><h2>${item.title}</h2>${item.html}`;
  detailContent.querySelectorAll("[data-open]").forEach(button => button.addEventListener("click", () => window.open(button.dataset.open, "_blank", "noopener,noreferrer")));
}
document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => setView(btn.dataset.view)));
$("#integrationsAction").addEventListener("click", () => setView("integrations"));

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}