import { GoogleGenAI } from "@google/genai";

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Use POST for chat requests." });
  }

  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    return res.status(503).json({
      error: "Gemini is not configured yet. Add GEMINI_API_KEY to your local .env.local or Vercel Environment Variables."
    });
  }

  try {
    const body = req.body || {};
    const message = typeof body.message === "string" ? body.message.trim() : "";
    const history = Array.isArray(body.history) ? body.history.slice(-8) : [];
    if (!message) return res.status(400).json({ error: "Please enter a message." });
    if (message.length > 4000) return res.status(413).json({ error: "Message is too long (maximum 4,000 characters)." });

    const safeHistory = history
      .filter(m => m && ["user", "model"].includes(m.role) && typeof m.text === "string")
      .map(m => ({ role: m.role, parts: [{ text: m.text.slice(0, 2000) }] }));

    const ai = new GoogleGenAI({ apiKey: key });
    const response = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-2.5-flash",
      contents: [...safeHistory, { role: "user", parts: [{ text: message }] }],
      config: {
        systemInstruction:
          "You are JARVIS, a helpful, concise personal AI assistant. You run in a user-controlled web app. Do not claim to have device access, account access, or to have performed external actions unless a connected integration actually confirms it. For emails, messages, purchases, or other consequential actions, ask for confirmation and use only explicitly configured integrations. Never ask the user to share passwords or API keys in chat."
      }
    });
    return res.status(200).json({ reply: response.text || "I couldn't generate a reply. Please try again." });
  } catch (err) {
    console.error("JARVIS chat error:", err?.message || "Unknown error");
    return res.status(500).json({ error: "JARVIS couldn't reach Gemini. Check your server key, quota, and deployment logs." });
  }
}